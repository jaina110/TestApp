//
//  ViewController.h
//  test
//
//  Created by administrator on 30/06/16.
//  Copyright © 2016 Yespay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

//comment in Viewcontroller .h
@end

