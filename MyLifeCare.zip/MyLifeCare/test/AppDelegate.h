//
//  AppDelegate.h
//  test
//
//  Created by administrator on 30/06/16.
//  Copyright © 2016 Yespay. All rights reserved.
//

#import <UIKit/UIKit.h>
// Add comments 
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

